import { ProductCard } from "@/components/product-card"

const dailyProducts = [
  {
    id: 1,
    name: "Canasta Premium Navideña",
    description: "Vino tinto reserva, chocolates gourmet y decoración navideña de lujo",
    price: 2899,
    originalPrice: 3500,
    image: "/placeholder.svg?height=400&width=400",
    category: "Canastas con Vino",
    featured: true,
  },
  {
    id: 2,
    name: "Arreglo Floral Navideño Exclusivo",
    description: "Rosas rojas premium, flores blancas y decoración dorada artesanal",
    price: 1899,
    originalPrice: 2400,
    image: "/placeholder.svg?height=400&width=400",
    category: "Flores",
    featured: true,
  },
  {
    id: 3,
    name: "Canasta Frutal Deluxe",
    description: "Frutas frescas premium importadas y frutos secos selectos",
    price: 1299,
    originalPrice: 1600,
    image: "/placeholder.svg?height=400&width=400",
    category: "Canastas Frutales",
    featured: true,
  },
  {
    id: 4,
    name: "Regalo Corporativo Elegante",
    description: "Whisky premium escocés, chocolates belgas y tarjeta personalizada",
    price: 4500,
    originalPrice: 5800,
    image: "/placeholder.svg?height=400&width=400",
    category: "Canastas con Whisky",
    featured: true,
  },
]

export function DailySelection() {
  return (
    <section className="py-20 bg-gradient-to-b from-gray-900 to-black">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16 fade-in-up">
          <div className="inline-flex items-center gap-3 bg-gold-400/10 border border-gold-400/20 text-gold-400 px-6 py-3 rounded-full text-sm font-medium mb-6 backdrop-blur-sm">
            <span className="w-2 h-2 bg-gold-400 rounded-full animate-pulse"></span>
            Selección Exclusiva del Día
          </div>
          <h2 className="text-4xl lg:text-5xl font-playfair font-bold text-white mb-6">
            Productos <span className="text-gold-400">Destacados</span>
          </h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto font-light leading-relaxed">
            Descubre nuestra cuidadosa selección diaria de los mejores regalos navideños de lujo con precios especiales
            exclusivos
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {dailyProducts.map((product, index) => (
            <div key={product.id} className="scale-in" style={{ animationDelay: `${index * 150}ms` }}>
              <ProductCard product={product} />
            </div>
          ))}
        </div>

        <div className="text-center mt-16 fade-in-up">
          <p className="text-gray-400 mb-6 font-light">¿Buscas algo más específico?</p>
          <a
            href="/catalogo"
            className="inline-flex items-center text-gold-400 hover:text-gold-300 font-medium text-lg elegant-underline transition-colors duration-300"
          >
            Explorar Catálogo Completo →
          </a>
        </div>
      </div>
    </section>
  )
}
