import Link from "next/link"
import { Card, CardContent } from "@/components/ui/card"

const categories = [
  {
    name: "Canastas con Vino",
    description: "Selección premium de vinos y acompañamientos de lujo",
    href: "/catalogo/canastas-vino",
    image: "/placeholder.svg?height=300&width=400",
    icon: "🍷",
  },
  {
    name: "Canastas con Whisky",
    description: "Whiskys selectos y complementos gourmet exclusivos",
    href: "/catalogo/canastas-whisky",
    image: "/placeholder.svg?height=300&width=400",
    icon: "🥃",
  },
  {
    name: "Canastas sin Licor",
    description: "Deliciosas opciones premium para toda la familia",
    href: "/catalogo/canastas-sin-licor",
    image: "/placeholder.svg?height=300&width=400",
    icon: "🍫",
  },
  {
    name: "Regalos Navideños",
    description: "Artículos especiales de lujo para la temporada",
    href: "/catalogo/regalos-navidenos",
    image: "/placeholder.svg?height=300&width=400",
    icon: "🎁",
  },
  {
    name: "Detalles Pequeños",
    description: "Pequeños gestos con gran elegancia y significado",
    href: "/catalogo/detalles-pequenos",
    image: "/placeholder.svg?height=300&width=400",
    icon: "✨",
  },
  {
    name: "Canastas Frutales",
    description: "Frutas frescas premium y frutos secos selectos",
    href: "/catalogo/canastas-frutales",
    image: "/placeholder.svg?height=300&width=400",
    icon: "🍎",
  },
  {
    name: "Flores",
    description: "Arreglos florales únicos y elegantes de alta calidad",
    href: "/catalogo/flores",
    image: "/placeholder.svg?height=300&width=400",
    icon: "🌹",
  },
]

export function CategoriesGrid() {
  return (
    <section className="py-20 bg-gradient-to-b from-black to-gray-900">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16 fade-in-up">
          <h2 className="text-4xl lg:text-5xl font-playfair font-bold text-white mb-6">
            Explora Nuestras <span className="text-gold-400">Colecciones Exclusivas</span>
          </h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto font-light leading-relaxed">
            Cada categoría ha sido cuidadosamente curada para ofrecerte la más alta calidad y elegancia en regalos
            navideños premium
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
          {categories.map((category, index) => (
            <Link key={category.href} href={category.href}>
              <Card
                className="group bg-black border-2 border-gold-500/20 hover:border-gold-400 transition-all duration-500 overflow-hidden hover:luxury-glow cursor-pointer scale-in"
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <div className="relative overflow-hidden">
                  <img
                    src={category.image || "/placeholder.svg"}
                    alt={category.name}
                    className="w-full h-48 object-cover group-hover:scale-110 transition-transform duration-700"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent"></div>

                  {/* Icon overlay */}
                  <div className="absolute top-4 right-4 w-12 h-12 bg-gold-400/90 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
                    <span className="text-2xl">{category.icon}</span>
                  </div>
                </div>

                <CardContent className="p-6 bg-black">
                  <h3 className="text-xl font-playfair font-semibold text-white mb-3 group-hover:text-gold-400 transition-colors duration-300">
                    {category.name}
                  </h3>
                  <p className="text-gray-400 text-sm font-light leading-relaxed">{category.description}</p>

                  {/* Decorative line */}
                  <div className="mt-4 h-px bg-gradient-to-r from-transparent via-gold-400 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      </div>
    </section>
  )
}
