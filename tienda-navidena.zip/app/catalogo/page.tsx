import { ProductCard } from "@/components/product-card"

const allProducts = [
  {
    id: 1,
    name: "Canasta Premium Navideña",
    description: "Vino tinto reserva, chocolates gourmet y decoración navideña",
    price: 89.99,
    originalPrice: 120.0,
    image: "/placeholder.svg?height=300&width=300",
    category: "Canastas con Vino",
    featured: true,
  },
  {
    id: 2,
    name: "Arreglo Floral Navideño",
    description: "Rosas rojas, flores blancas y decoración dorada",
    price: 65.99,
    originalPrice: 85.0,
    image: "/placeholder.svg?height=300&width=300",
    category: "Flores",
    featured: true,
  },
  {
    id: 3,
    name: "Canasta Frutal Deluxe",
    description: "Frutas frescas premium y frutos secos selectos",
    price: 45.99,
    originalPrice: 60.0,
    image: "/placeholder.svg?height=300&width=300",
    category: "Canastas Frutales",
    featured: true,
  },
  {
    id: 4,
    name: "Regalo Corporativo Elegante",
    description: "Whisky premium, chocolates y tarjeta personalizada",
    price: 150.0,
    originalPrice: 200.0,
    image: "/placeholder.svg?height=300&width=300",
    category: "Canastas con Whisky",
    featured: true,
  },
  {
    id: 5,
    name: "Canasta Familiar Sin Licor",
    description: "Galletas artesanales, mermeladas y dulces navideños",
    price: 35.99,
    image: "/placeholder.svg?height=300&width=300",
    category: "Canastas sin Licor",
  },
  {
    id: 6,
    name: "Detalle Navideño Pequeño",
    description: "Mini canasta con chocolates y tarjeta personalizada",
    price: 15.99,
    image: "/placeholder.svg?height=300&width=300",
    category: "Detalles Pequeños",
  },
  {
    id: 7,
    name: "Ornamento Navideño Premium",
    description: "Decoración navideña artesanal con acabados dorados",
    price: 25.99,
    image: "/placeholder.svg?height=300&width=300",
    category: "Regalos Navideños",
  },
  {
    id: 8,
    name: "Ramo de Rosas Rojas",
    description: "Docena de rosas rojas frescas con papel dorado",
    price: 55.99,
    image: "/placeholder.svg?height=300&width=300",
    category: "Flores",
  },
]

export default function CatalogoPage() {
  return (
    <div className="container mx-auto px-4 py-12">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold text-gray-900 mb-4">Catálogo Completo</h1>
        <p className="text-xl text-gray-600 max-w-2xl mx-auto">
          Descubre toda nuestra colección de regalos navideños premium
        </p>
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {allProducts.map((product) => (
          <ProductCard key={product.id} product={product} />
        ))}
      </div>
    </div>
  )
}
