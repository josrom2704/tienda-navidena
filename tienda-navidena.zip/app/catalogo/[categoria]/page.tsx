import { ProductCard } from "@/components/product-card"
import { notFound } from "next/navigation"

const categoryProducts = {
  "canastas-vino": [
    {
      id: 1,
      name: "Canasta Premium Navideña",
      description: "Vino tinto reserva, chocolates gourmet y decoración navideña",
      price: 89.99,
      originalPrice: 120.0,
      image: "/placeholder.svg?height=300&width=300",
      category: "Canastas con Vino",
      featured: true,
    },
    {
      id: 9,
      name: "Canasta Vino Blanco Elegante",
      description: "Vino blanco premium, quesos selectos y galletas artesanales",
      price: 75.99,
      image: "/placeholder.svg?height=300&width=300",
      category: "Canastas con Vino",
    },
    {
      id: 10,
      name: "Canasta Vino Rosé Romántica",
      description: "Vino rosé, chocolates belgas y flores frescas",
      price: 95.99,
      image: "/placeholder.svg?height=300&width=300",
      category: "Canastas con Vino",
    },
  ],
  "canastas-whisky": [
    {
      id: 4,
      name: "Regalo Corporativo Elegante",
      description: "Whisky premium, chocolates y tarjeta personalizada",
      price: 150.0,
      originalPrice: 200.0,
      image: "/placeholder.svg?height=300&width=300",
      category: "Canastas con Whisky",
      featured: true,
    },
    {
      id: 11,
      name: "Canasta Whisky Escocés",
      description: "Whisky escocés single malt, frutos secos premium",
      price: 180.0,
      image: "/placeholder.svg?height=300&width=300",
      category: "Canastas con Whisky",
    },
  ],
  "canastas-sin-licor": [
    {
      id: 5,
      name: "Canasta Familiar Sin Licor",
      description: "Galletas artesanales, mermeladas y dulces navideños",
      price: 35.99,
      image: "/placeholder.svg?height=300&width=300",
      category: "Canastas sin Licor",
    },
    {
      id: 12,
      name: "Canasta Dulces Gourmet",
      description: "Chocolates artesanales, caramelos y dulces premium",
      price: 42.99,
      image: "/placeholder.svg?height=300&width=300",
      category: "Canastas sin Licor",
    },
  ],
  "regalos-navidenos": [
    {
      id: 7,
      name: "Ornamento Navideño Premium",
      description: "Decoración navideña artesanal con acabados dorados",
      price: 25.99,
      image: "/placeholder.svg?height=300&width=300",
      category: "Regalos Navideños",
    },
    {
      id: 13,
      name: "Set Decorativo Navideño",
      description: "Conjunto de adornos navideños elegantes y velas aromáticas",
      price: 45.99,
      image: "/placeholder.svg?height=300&width=300",
      category: "Regalos Navideños",
    },
  ],
  "detalles-pequenos": [
    {
      id: 6,
      name: "Detalle Navideño Pequeño",
      description: "Mini canasta con chocolates y tarjeta personalizada",
      price: 15.99,
      image: "/placeholder.svg?height=300&width=300",
      category: "Detalles Pequeños",
    },
    {
      id: 14,
      name: "Mini Arreglo Floral",
      description: "Pequeño arreglo con flores de temporada y lazo dorado",
      price: 18.99,
      image: "/placeholder.svg?height=300&width=300",
      category: "Detalles Pequeños",
    },
  ],
  "canastas-frutales": [
    {
      id: 3,
      name: "Canasta Frutal Deluxe",
      description: "Frutas frescas premium y frutos secos selectos",
      price: 45.99,
      originalPrice: 60.0,
      image: "/placeholder.svg?height=300&width=300",
      category: "Canastas Frutales",
      featured: true,
    },
    {
      id: 15,
      name: "Canasta Frutas Tropicales",
      description: "Selección de frutas tropicales frescas y exóticas",
      price: 52.99,
      image: "/placeholder.svg?height=300&width=300",
      category: "Canastas Frutales",
    },
  ],
  flores: [
    {
      id: 2,
      name: "Arreglo Floral Navideño",
      description: "Rosas rojas, flores blancas y decoración dorada",
      price: 65.99,
      originalPrice: 85.0,
      image: "/placeholder.svg?height=300&width=300",
      category: "Flores",
      featured: true,
    },
    {
      id: 8,
      name: "Ramo de Rosas Rojas",
      description: "Docena de rosas rojas frescas con papel dorado",
      price: 55.99,
      image: "/placeholder.svg?height=300&width=300",
      category: "Flores",
    },
    {
      id: 16,
      name: "Arreglo Floral Elegante",
      description: "Flores blancas y verdes con toques dorados navideños",
      price: 72.99,
      image: "/placeholder.svg?height=300&width=300",
      category: "Flores",
    },
  ],
}

const categoryNames = {
  "canastas-vino": "Canastas con Vino",
  "canastas-whisky": "Canastas con Whisky",
  "canastas-sin-licor": "Canastas sin Licor",
  "regalos-navidenos": "Regalos Navideños",
  "detalles-pequenos": "Detalles Pequeños",
  "canastas-frutales": "Canastas Frutales",
  flores: "Flores",
}

export default function CategoriaPage({ params }: { params: { categoria: string } }) {
  const products = categoryProducts[params.categoria as keyof typeof categoryProducts]
  const categoryName = categoryNames[params.categoria as keyof typeof categoryNames]

  if (!products || !categoryName) {
    notFound()
  }

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold text-gray-900 mb-4">{categoryName}</h1>
        <p className="text-xl text-gray-600 max-w-2xl mx-auto">
          Descubre nuestra selección especial de {categoryName.toLowerCase()}
        </p>
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {products.map((product) => (
          <ProductCard key={product.id} product={product} />
        ))}
      </div>
    </div>
  )
}
